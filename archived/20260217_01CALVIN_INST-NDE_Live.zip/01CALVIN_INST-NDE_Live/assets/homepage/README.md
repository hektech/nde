
##Homepage 

The homepage folder includes the following template files that you can use for editing the content and style of your landing page 
You can find more details [Customizing Landing Page](https://knowledge.exlibrisgroup.com/Primo/Product_Documentation/020Primo_VE/Primo_VE_(English)/030Primo_VE_User_Interface/010NDE_UI_Customization_-_Best_Practices#Customizing_the_Landing_Page)





